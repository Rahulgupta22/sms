<!doctype html>
<html lang="en">
 <head>
  <meta charset="UTF-8">
  <meta name="Generator" content="EditPlus�">
  <meta name="Author" content="">
  <meta name="Keywords" content="">
  <meta name="Description" content="">
  <title>Admin Login</title>
 </head>
 <body>
  <h2 align="center">Admin Login</h2>
  <form action="validation.php" method="post">
  <table align="center">
  
  <tr>
  <td>Username</td>
  <td><input type="text" name="username"/></td>
  </tr>

  <td>Password</td>
  <td><input type="password" name="password"/></td>
  </tr>

  <td></td>
  <td><input type="submit" value="Login"/></td>
  </tr>
  </table>
  </form>
 </body>
</html>