<?php

   $con = mysqli_connect('localhost','root','','cms');

	if($con == false)
	{
	   echo "Connection is not done";
	}
	
	
?>