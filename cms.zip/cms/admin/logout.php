//<?php
session_start();
session_destroy();
//header('location:cms/logout.php');
header('location:http://localhost/cms/login.php');
?>