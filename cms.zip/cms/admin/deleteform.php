
<?php
	include('../dbcon.php');

	$id=$_REQUEST['sid'];
		

		$qry="delete from student where id='$id'";

		//$run=mysqli_query($con,$qry);
		//if($run == true)
		if(mysqli_query($con,$qry))
		{
			?>
				<script>
					alert('Data Deleted Successfuly');
					window.open('deletestudent.php','_self');
				</script>
				<?php
		}
		
?>
