<!doctype html>
<html lang="en">
 <head>
 <meta charset="UTF-8">
  <title>Student Management System</title>
  <link href="../css/style.css" rel="stylesheet" type="text/css">
 </head>
 <body bgcolor="#FFFF33";>
</body>
</html>