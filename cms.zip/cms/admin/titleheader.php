<div class="admintitle" align="center">
 <h4>
	<a href="admindash.php" style="float:left; margin-right:30px; color:#fff; font-size:20px;">Back to Dashboard</a>
 <a href="logout.php" style="float:right; margin-right:30px; color:#fff; font-size:20px;">Logout</a></h4>
	
 <h1>Welcome to Admin Dashboard</h1>
 </div>
